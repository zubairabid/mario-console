from distutils.core import setup
import setuptools

setup(
    name = 'Mario',
    version = '0.9.1',
    packages = setuptools.find_packages('.'),
    author = 'Zubair Abid',
    author_email = 'zubairabid1999@research.iiit.ac.in',
    test_suite = 'pytest',
    tests_require = ['pytest',],
)
